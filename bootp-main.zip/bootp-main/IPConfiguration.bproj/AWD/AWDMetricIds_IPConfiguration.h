//
//  AWDMetricIds_IPConfiguration.h
//  AppleWirelessDiagnostics
//
//  WARNING :: DO NOT MODIFY THIS FILE!
//
//     This file is auto-generated! Do not modify it or your changes will get overwritten!
//

#ifndef AWD_MetricId_HeaderGuard_IPConfiguration
#define AWD_MetricId_HeaderGuard_IPConfiguration

// Component Id:
// ---------------
//    Use this value for any API requesting the "component id" for your component.
enum {
    AWDComponentId_IPConfiguration = 0x67
};


// Simple Metrics:
// ---------------
//    This component currently has no metrics compatible with the 'simple metric' API.


// General Metrics:
// ----------------
enum {
    AWDMetricId_IPConfiguration_IPv6Report = 0x670000
};

#endif  // AWD_MetricId_HeaderGuard_IPConfiguration

This pack was originally made by BionicBen1218.
The geometry for the HD capes and banner capes were created by FloppyDolphin and LEGEND EAGLE.
Badlion/PvP Lounge capes were ported by Coolcreeper13C.
Cape designs were originally made by Mojang, BionicBen1218, and other individuals and companies.
If you have found this pack on an external source or video outside of his channel, it was taken from BionicBen1218, and you can report if this pack was stolen on their channel.
By using this pack, you abide by the following terms:

- YOU CANNOT MAKE MODIFICATIONS OF ANY KIND TO THIS README.TXT FILE.
- You are allowed to use SOME capes for your own use as long as you give credit.
- You are not allowed to upload modified versions of this pack of any kind.
- You are allowed to make private changes to this pack, as long as you keep them to yourself.
- If you wish to make a video on the pack, please ask BionicBen1218 before publishing.
- If you are making a video about this skin pack, you must give credit to BionicBen1218 and give a link to the original tutorial and/or BionicBen1218's channel.
- If you upload a showcase of this pack, you cannot create your own download link. It must redirect to BionicBen1218's tutorial. 
- If you are wanting to upload a video about this pack, please simply make it a showcase video.

Failure to comply with these terms may result in a copyright strike.
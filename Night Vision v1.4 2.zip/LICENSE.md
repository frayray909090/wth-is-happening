# License

## You are allowed to

* Use the pack in screenshots and videos

* Modify the pack for personal use

* Publish a modified version of the pack*

* Include parts of the pack in your pack*

* Share the pack files*

*Credit required, add a link to [my website](https://luracasmus.wixsite.com/luracasmus) if possible

## You are not allowed to

* Claim the pack files as your own

int file_check_passwd(char *, char *);
int nis_check_passwd(char *, char *);
int od_check_passwd(const char *, const char *);
int pam_check_passwd(char *);
void checkpasswd(char *, char *);
